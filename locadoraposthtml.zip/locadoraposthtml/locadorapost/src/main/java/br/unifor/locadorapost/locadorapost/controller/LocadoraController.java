package br.unifor.locadorapost.locadorapost.controller;
import br.unifor.locadorapost.locadorapost.model.*;
import br.unifor.locadorapost.locadorapost.service.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

@RestController
@RequestMapping("/locadora")
public class LocadoraController {

    @Autowired
    private FilmeService filmeService;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private LocacaoService locacaoService;

    private final List<SseEmitter> emitters = new CopyOnWriteArrayList<>();

    // Novo método para transmitir eventos via SSE
    @GetMapping("/stream")
    public SseEmitter stream() {
        SseEmitter emitter = new SseEmitter();
        emitters.add(emitter);
        emitter.onCompletion(() -> emitters.remove(emitter));
        emitter.onTimeout(() -> emitters.remove(emitter));
        return emitter;
    }

    // Método para enviar eventos para o cliente
    private void sendEvent(Map<String, Object> requestData) {
        emitters.forEach(emitter -> {
            try {
                emitter.send(SseEmitter.event().data(requestData));
            } catch (IOException e) {
                emitters.remove(emitter);
            }
        });
    }

    // Endpoint para cadastrar um filme
    @PostMapping("/filmes")
    public String cadastrarFilme(@RequestBody Map<String, String> filmeRequest) {
        try {
            String titulo = filmeRequest.get("titulo");
            String genero = filmeRequest.get("genero");
            String formato = filmeRequest.get("formato");

            Filme filme = criarFilme(titulo, genero, formato);
            filmeService.adicionarFilme(filme);

            // Criar e enviar evento
            Map<String, Object> requestData = new HashMap<>();
            requestData.put("method", "POST");
            requestData.put("url", "/locadora/filmes");
            requestData.put("body", filmeRequest);
            sendEvent(requestData);

            return "Filme cadastrado com sucesso!";
        } catch (IllegalArgumentException e) {
            return e.getMessage();
        }
    }

    private Filme criarFilme(String titulo, String genero, String formato) {
        if (formato.equalsIgnoreCase("DVD")) {
            return new FilmeDVD(titulo, genero);
        } else if (formato.equalsIgnoreCase("Blu-ray")) {
            return new FilmeBluRay(titulo, genero);
        } else {
            throw new IllegalArgumentException("Formato desconhecido.");
        }
    }

    // Endpoint para cadastrar um cliente
    @PostMapping("/clientes")
    public String cadastrarCliente(@RequestBody Cliente cliente) {
        clienteService.adicionarCliente(cliente);

        // Criar e enviar evento
        Map<String, Object> requestData = new HashMap<>();
        requestData.put("method", "POST");
        requestData.put("url", "/locadora/clientes");
        requestData.put("body", cliente);
        sendEvent(requestData);

        return "Cliente cadastrado com sucesso!";
    }

    // Endpoint para realizar uma locação
    @PostMapping("/locacoes")
    public String locarFilme(@RequestBody Map<String, String> request) {
        try {
            String documentoCliente = request.get("documentoCliente");
            String tituloFilme = request.get("tituloFilme");

            locacaoService.realizarLocacao(documentoCliente, tituloFilme);

            // Criar e enviar evento
            Map<String, Object> requestData = new HashMap<>();
            requestData.put("method", "POST");
            requestData.put("url", "/locadora/locacoes");
            requestData.put("body", request);
            sendEvent(requestData);

            return "Locação realizada com sucesso!";
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    // Endpoint para realizar uma devolução
    @PostMapping("/devolucoes")
    public String devolverFilme(@RequestBody Map<String, String> locacaoRequest) {
        try {
            String documentoCliente = locacaoRequest.get("documentoCliente");
            String tituloFilme = locacaoRequest.get("tituloFilme");

            locacaoService.realizarDevolucao(documentoCliente, tituloFilme);

            // Criar e enviar evento
            Map<String, Object> requestData = new HashMap<>();
            requestData.put("method", "POST");
            requestData.put("url", "/locadora/devolucoes");
            requestData.put("body", locacaoRequest);
            sendEvent(requestData);

            return "Devolução realizada com sucesso!";
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    // Endpoint para deletar um cliente
    @DeleteMapping("/clientes/{documento}")
    public String deletarCliente(@PathVariable String documento) {
        boolean removido = clienteService.deletarCliente(documento);

        // Criar e enviar evento
        Map<String, Object> requestData = new HashMap<>();
        requestData.put("method", "DELETE");
        requestData.put("url", "/locadora/clientes/" + documento);
        requestData.put("body", null);
        sendEvent(requestData);

        return removido ? "Cliente deletado com sucesso!" : "Cliente não encontrado!";
    }

    // Endpoint para listar todos os filmes
    @GetMapping("/filmes")
    public List<Filme> listarFilmes() {
        List<Filme> filmes = filmeService.getFilmes();

        // Criar e enviar evento
        Map<String, Object> requestData = new HashMap<>();
        requestData.put("method", "GET");
        requestData.put("url", "/locadora/filmes");
        requestData.put("body", null);
        requestData.put("response", filmes);
        sendEvent(requestData);

        return filmes;
    }

    // Endpoint para listar todos os clientes
    @GetMapping("/clientes")
    public List<Cliente> listarClientes() {
        List<Cliente> clientes = clienteService.getClientes();

        // Criar e enviar evento
        Map<String, Object> requestData = new HashMap<>();
        requestData.put("method", "GET");
        requestData.put("url", "/locadora/clientes");
        requestData.put("body", null);
        requestData.put("response", clientes);
        sendEvent(requestData);

        return clientes;
    }

    // Endpoint para listar todas as locações
    @GetMapping("/locacoes")
    public List<Locacao> listarLocacoes() {
        List<Locacao> locacoes = locacaoService.getLocacoes();

        // Criar e enviar evento
        Map<String, Object> requestData = new HashMap<>();
        requestData.put("method", "GET");
        requestData.put("url", "/locadora/locacoes");
        requestData.put("body", null);
        requestData.put("response", locacoes);
        sendEvent(requestData);

        return locacoes;
    }
}
