package br.unifor.locadorapost.locadorapost;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocadorapostApplicationTests {

	@Test
	void contextLoads() {
	}

}
